package com.capstone.passionventure

data class User(
    val username: String,
    val password: String,
    val email: String
)